
public class Ex1K {

	public static void main(String[] args) {
		int fat = 1;
		for (int i = 1; i <= 10; i++) {
			if (i % 2 != 0) {
				fat = fat * i;
				System.out.print(" " + fat);}
			
		}

	}

}
