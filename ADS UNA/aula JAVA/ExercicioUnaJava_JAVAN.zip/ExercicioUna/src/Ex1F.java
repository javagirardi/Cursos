
public class Ex1F {

	public static void main(String[] args) {
		
		for (int i = 1; i < 200; i++) {
			if (i % 4 == 0)
				System.out.println(i);
		}
	}

}
