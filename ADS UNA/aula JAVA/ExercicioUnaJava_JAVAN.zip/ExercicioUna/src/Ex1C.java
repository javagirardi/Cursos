
public class Ex1C {

	public static void main(String[] args) {

		int soma;
		soma = 0;

		for (int i = 1; i <= 100; i++) {
			soma = soma + i;
			System.out.println("A soma obtida de cada um dos cem n�meros � " + soma);

		}

	}

}
