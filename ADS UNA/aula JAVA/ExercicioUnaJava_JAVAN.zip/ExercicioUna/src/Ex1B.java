
public class Ex1B {

	public static void main(String[] args) {

		for (int i = 0; i <= 10; i++) {
			System.out.println("A tabuada de 7 � = " + i * 7);

		}

	}

}
