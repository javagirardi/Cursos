
public class Ex1G {

	public static void main(String[] args) {

		for (int i = 0; i <= 15; i++)

			System.out.println(Math.pow(3, i));

	}

}
