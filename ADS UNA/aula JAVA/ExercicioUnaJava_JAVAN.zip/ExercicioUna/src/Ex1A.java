
public class Ex1A {

	public static void main(String[] args) {

		for (int i = 15; i <= 200; i++) {
			System.out.println("O quadrado de " + i + " � " + (i * i));

		}

	}

}
