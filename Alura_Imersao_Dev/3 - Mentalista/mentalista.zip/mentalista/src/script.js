var numeroSecreto = parseInt(Math.random() *10)
var tentativas = 3

while (tentativas) {
    var chute = parseInt(prompt("Digite um número entre 0 e 10"))

    if(numeroSecreto == chute){
      console.log("Acertou")
      break
    } else if (chute > numeroSecreto){
      console.log("O numero secreto é menor")
      tentativas = tentativas -1
    } else if (chute < numeroSecreto){
      console.log("O numero secreto é maior")  
      tentativas = tentativas -1
    } 
}

if (chute != numeroSecreto){
  alert("Suas tentativas acabaram. O numero secreto era " + numeroSecreto)
}